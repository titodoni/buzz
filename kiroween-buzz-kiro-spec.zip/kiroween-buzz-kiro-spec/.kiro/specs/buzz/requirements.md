# Buzz — Requirements

## Introduction

Buzz revives Yahoo Messenger for the modern web. A signed-in user sees
who is online, sets a status, and chats 1:1 in real time. The signature
interaction is Nudge: shake the other person's chat window when they
ignore you. There is no feed, no algorithm, no infinite scroll.

## Glossary

- **Presence**: a friend's live state, online, away, busy, or offline.
- **Status**: a short custom message shown under a friend's name.
- **Now playing**: a manually typed song/artist line, shown like a status.
- **Nudge**: a shake + sound sent to one chat window, with a cooldown.
- **Offline message**: a chat message sent while the friend is offline,
  delivered when they return.

## Requirements

### 1. Email sign-in

- WHEN a visitor opens the app THEN they see a sign-in page with email
  and password, plus a sign-up link.
- WHEN a new user signs up THEN an account is created and a profile is
  created with a default display name and avatar.
- WHEN a signed-in user reloads the page THEN they stay signed in.
- WHEN a signed-in user signs out THEN they return to the sign-in page.

### 2. Profile

- WHEN a user opens their profile THEN they can change display name,
  avatar (upload a small image), and status message.
- WHEN a display name is empty THEN the previous name is kept and an
  error is shown.
- WHEN a profile is saved THEN the change is visible to friends at once.

### 3. Friends

- WHEN a user searches by email or display name THEN matching users are
  listed, excluding the user themself.
- WHEN a user sends a friend request THEN the other user sees it in a
  pending list.
- WHEN a user accepts a request THEN both users appear in each other's
  friend list.
- WHEN a user declines or removes a friend THEN no chat history is shown
  for that pair until they are friends again.

### 4. Presence

- WHEN a user is active in the app THEN friends see them as online.
- WHEN a user has no activity for 5 minutes THEN friends see them as away.
- WHEN a user sets busy THEN friends see them as busy until changed.
- WHEN a user closes the app THEN friends see them as offline within
  30 seconds.
- WHEN a friend's presence changes THEN the friend list updates without
  a page reload.

### 5. 1:1 real-time chat

- WHEN two friends open a chat THEN each sees the shared message history.
- WHEN a user sends a message THEN the friend receives it in under
  2 seconds without reloading.
- WHEN a message is sent THEN it is stored and survives a reload.
- WHEN a message is empty or only whitespace THEN it is not sent.

### 6. Nudge

- WHEN a user clicks Nudge in a chat THEN the friend's chat window shakes
  and a short sound plays.
- WHEN a Nudge is sent THEN the sender sees "You nudged <name>" in the chat.
- WHEN a Nudge was sent less than 10 seconds ago THEN the button is
  disabled until the cooldown ends.
- WHEN the friend is offline THEN Nudge is disabled and explains why.

### 7. Status and now playing

- WHEN a user sets a status message THEN friends see it under their name.
- WHEN a user sets a now playing line THEN friends see it with a music note.
- WHEN a status is longer than 140 characters THEN it is rejected.

### 8. Emoticons and skin

- WHEN a user opens the emoticon picker THEN a classic-style emoticon
  pack is shown.
- WHEN a user picks an emoticon THEN its shortcode is inserted at the
  cursor position in the message box.
- WHEN a message contains an emoticon shortcode THEN it renders as the
  emoticon image.
- WHEN the app loads THEN it uses the YM-era skin: purple, rounded
  corners, slightly glossy, readable contrast.

### 9. Offline messages

- WHEN a user sends a message to an offline friend THEN it is stored.
- WHEN the friend comes online THEN stored messages are delivered and
  marked read when opened.

### 10. Typing indicator

- WHEN a user types in a chat THEN the friend sees "<name> is typing..."
- WHEN the user stops typing for 3 seconds THEN the indicator clears.
